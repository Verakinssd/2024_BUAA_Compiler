package backend.ASM.FuncAsm;

public class InstructionAsm {
}
